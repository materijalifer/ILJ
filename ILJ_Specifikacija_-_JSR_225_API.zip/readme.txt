This ZIP archive contains two files. It describes the current state of the
XQuery API for Java(tm) (XQJ), and is subject to possibly significant
changes and should not be considered to be in any way final.

One of these files, XQJ_Spec_Early_Draft_Review_2006-04-20.pdf, is the Early
Draft Review edition of the XQuery API for Java(tm) (XQJ) 1.0 Specification. �

The other, XQJ_API_Early_Draft_Review_2006-04-20.zip, is a ZIP archive
containing the Early Draft Review edition of the Javadoc descriptions of the
XQuery API for Java(tm) (XQJ) 1.0. The contents of this ZIP archive should
be extracted into a directory of your choice, honoring the directory
structure of the files in the archive. 

Comments on the Specification and on the API itself should be sent to
mailto:jsr-225-comments@jcp.org 

