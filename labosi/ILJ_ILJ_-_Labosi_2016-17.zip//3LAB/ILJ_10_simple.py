import metacomm.combinatorics.all_pairs2
all_pairs = metacomm.combinatorics.all_pairs2.all_pairs2

"""
Demo of the basic functionality - just getting pairwise/n-wise combinations
"""

parameters = [ [ "t", "f" ]
             , [ "1", "2"]
             , [ "a", "b"]
             ]

# n=2 znaici "svi parovi" 
pairwise = all_pairs( parameters, n=2 )

print "SVIPAROVI:"
for i, v in enumerate(pairwise):
    print "%i:\t%s" % (i, str(v))


    